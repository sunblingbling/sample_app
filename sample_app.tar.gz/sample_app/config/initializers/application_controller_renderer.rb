# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '51df4100194f5c15392c867433cb6ad7bb86435035c1ac0ffacb93037a8f5a82439a1039591ab036c61b8ec654ec0c39aa760b0c7ed1aa09804c2c92bab8c043'