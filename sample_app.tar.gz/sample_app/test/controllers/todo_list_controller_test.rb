require 'test_helper'

class TodoListControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get todo_list_new_url
    assert_response :success
  end

end
